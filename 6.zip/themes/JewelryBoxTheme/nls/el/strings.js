define({
  "_themeLabel": "Θέμα Jewelry Box",
  "_layout_default": "Προεπιλεγμένη διάταξη",
  "_layout_layout1": "Διάταξη 1",
  "emptyDocablePanelTip": "Κάντε κλικ στο κουμπί + στην καρτέλα Widget για να προσθέσετε ένα widget. "
});