define({
  "_themeLabel": "珠宝盒主题",
  "_layout_default": "默认布局",
  "_layout_layout1": "布局 1",
  "emptyDocablePanelTip": "在微件选项卡中单击 + 按钮以添加微件。 "
});