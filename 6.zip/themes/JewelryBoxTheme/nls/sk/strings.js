define({
  "_themeLabel": "Motív Jewelry Box",
  "_layout_default": "Predvolené rozloženie",
  "_layout_layout1": "Rozloženie 1",
  "emptyDocablePanelTip": "Kliknite na tlačidlo + v paneli widgetov pre pridanie widgetu. "
});